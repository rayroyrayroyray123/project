import Dropzone from "../src/dropzone";

window.Dropzone = Dropzone;

export default Dropzone;
